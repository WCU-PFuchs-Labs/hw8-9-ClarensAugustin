/**
 * Code Template Author: Clarens Augustin
 * Submission by: 10/07/2025
 * Date: 10/03/2025
 * Purpose: Use of hierarchical inheritance.
 */


public abstract class Computer extends Electronics{

    // Fields attributes
    private String processor;
    private int ramAmount;
    private int storageAmount;
    private String os;

    // Constructor matching the super class
    public Computer(String electronicType, String name, String brand, double cost, int year, double weight,
                    String processor, int ramAmount, int storageAmount, String os) {
        super(electronicType, name, brand, cost, year, weight);
        this.processor = processor;
        this.ramAmount = ramAmount;
        this.storageAmount = storageAmount;
        this.os = os;
    }

    public String country(){
        return "Country Origin: United States.";
    }

    public abstract String powerOn();

    // String representation of class
    public String toString(){
        return super.toString() + "\nProcessor: " + processor + "\nRam: " + ramAmount + "GB\nStorage: " +
                storageAmount + "GB\nOperating System: " + os;


    }
}
