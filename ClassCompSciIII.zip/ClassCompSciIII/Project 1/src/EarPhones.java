/**
 * Code Template Author: Clarens Augustin
 * Submission by: 10/07/2025
 * Date: 10/03/2025
 * Purpose: Use of hierarchical inheritance.
 */


public class EarPhones extends Electronics{

    private String connectionType;
    private int batteryLife;

    // Constructor matching the super class
    public EarPhones(String electronicType, String name, String brand, double cost, int year, double weight,
                     String connectionType, int batteryLife) {
        super(electronicType, name, brand, cost, year, weight);
        this.connectionType = connectionType;
        this.batteryLife = batteryLife;
    }
    public String country(){
        return "Country Origin: United States.";
    }
    public String toString(){
        return super.toString() + "\nConnection Type: " + connectionType +"\nBattery Life: " + batteryLife + "%";
    }
}
