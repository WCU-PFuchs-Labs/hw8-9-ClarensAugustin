/**
 * Code Template Author: Clarens Augustin
 * Submission by: 10/07/2025
 * Date: 10/03/2025
 * Purpose: Use of hierarchical inheritance.
 */


public class CellPhone extends Electronics{
    // Fields attributes
    private String model;
    private String processor;
    private String carrier;

    // Constructor matching the super class
    public CellPhone(String electronicType, String name, String brand, double cost, int year, double weight,
                     String model, String processor, String carrier) {
        super(electronicType, name, brand, cost, year, weight);
        this.model = model;
        this.processor = processor;
        this.carrier = carrier;
    }

    public String country(){
        return "Country Origin United States.";
    }

    // String representation of class
    public String toString(){
        return super.toString() + "\nModel: " + model + "\nProcessor: " + processor + "\nCarrier: " + carrier;
    }
}
