/**
 * Code Template Author: Clarens Augustin
 * Submission by: 10/07/2025
 * Date: 10/03/2025
 * Purpose: Use of hierarchical inheritance.
 */


public class Monitor extends Electronics{

    // Fields attributes
    private String screenSize;
    private String screenResolution;
    private String screenType;

    // Constructor matching the super class
    public Monitor(String electronicType, String name, String brand, double cost, int year, double weight,
                    String screenSize, String screenResolultion, String screenType) {
        super(electronicType, name, brand, cost, year, weight);

        this.screenType = screenType;
        this.screenSize = screenSize;
        this.screenResolution = screenResolultion;
    }

    public String country(){
        return "Country Origin: Korea.";
    }

    // String representation of class
    public String toString(){
        return super.toString() + "\nScreen Size: " + screenSize +
                "\nScreen Resolution: " + screenResolution + "\nScreen Type: "
                + screenType;
    }
}
