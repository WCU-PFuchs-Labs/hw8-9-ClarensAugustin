public class Laptop extends Computer{

    public String formFactor;
    public String battery;
    public int threads;

    public Laptop(String electronicType, String name, String brand, double cost, int year, double weight, String processor,
                  int ramAmount, int storageAmount, String os, String formFactor, String battery, int threads) {
        super(electronicType, name, brand, cost, year, weight, processor, ramAmount, storageAmount, os);

        this.formFactor = formFactor;
        this.battery = battery;
        this.threads = threads;
    }

    public String powerOn(){
        return "Powering on";
    }

    public String toString(){
        return super.toString() + "\nMotherboard: " + formFactor + "\nBattery Type: " + battery + "Number of threads: " +
                                threads;
    }



}
