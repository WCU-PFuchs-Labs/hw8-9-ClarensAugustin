/**
 * Code Template Author: Clarens Augustin
 * Submission by: 10/07/2025
 * Date: 10/03/2025
 * Purpose: Use of hierarchical inheritance. Creating multiple subclasses
 * from the Electronic class. All classes inherit from the Electronic class, and the Laptop class is a subclass of computer
 * Which creates a multilevel inheritance. Since there's multiple classes using the Electronic class as a parent, this project
 * also showcase hierarchical inheritance. I think this project showcase a great use of inheritance, a little polymorphism
 * with the abstract methods and class. Also, this project obviously touch a little on abstraction.
 */

public class Main {
    public static void main(String[] args) {

        Electronics electronics = new CellPhone("Cell Phone", "Iphone", "Apple",
                800.00, 2025,2, "Iphone 17", "A19 chip", "T-Mobile" );

        System.out.println(electronics);

        EarPhones earPhones = new EarPhones("Headphone", "Airpods" ,"Apple", 250, 2025, .5,
                "Bluetooth", 100);

        System.out.println("\n" + earPhones);

        Electronics computer = new Laptop("Computer", "Lenovo Ideapad", "Lenovo", 950, 2024, 8
                , "AMD Ryzen 7", 16, 1000, "Windows", "SODIMM", "Lithium ion", 12) {
        };

        System.out.println("\n"+ computer + "\n");

        Electronics monitor = new Monitor("Monitor", "Samsung Odyssey", "Samsung",
               200, 2024, 10,  "24 Inch", "1920 X 1080P", "Led");

        System.out.println("\n"+monitor + "\nCountry Origin: " + monitor.country());



    }
}