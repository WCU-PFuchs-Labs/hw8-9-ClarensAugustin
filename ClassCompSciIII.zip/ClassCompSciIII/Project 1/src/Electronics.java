/**
 * Code Template Author: Clarens Augustin
 * Submission by: 10/07/2025
 * Date: 10/03/2025
 * Purpose: Use of hierarchical inheritance.
 */

public abstract class Electronics {

    // Fields attributes
    private double weight;
    private double cost;
    private String brand;
    private int year;
    private String name;
    private String electronicType;

    public Electronics(String electronicType, String name, String brand, double cost,
                        int year, double weight){
        this.name = name;
        this.brand = brand;
        this.cost = cost;
        this.year = year;
        this.weight = weight;
        this.electronicType = electronicType;
    }

    // getters
    public String getName(){
        return this.name;
    }

    public String getBrand(){
        return this.brand;
    }

    public double getCost(){
        return this.cost;
    }

    public int getYear(){
        return this.year;
    }

    public double getWeight(){
        return this.weight;
    }

    public String getElectronicType(){ return this.electronicType; }

    // Abstract method
    public abstract String country();


    // String representation of class
    public String toString(){
        return electronicType + "\n\nName: " + name + "\nBrand: " + brand + "\nCost: $" + cost + "\nYear: "
                + year + "\nWeight: " + weight + " pounds";
    }
}
