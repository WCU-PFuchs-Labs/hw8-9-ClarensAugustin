public abstract class Unop extends Op {

        public abstract double eval(double [] values);

        @Override
        public abstract String toString();
    }

