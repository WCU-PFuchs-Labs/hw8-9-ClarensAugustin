package Binary;
import java.util.Random;

/**
 * Code Template Author: Clarens Augustin
 * Purpose: Test Nodes with random arithmetic expressions
 */
public class TestArithmetic {
    private static Random rand = new Random();

    // Creates a random constant node with value between 1 and 20
    private static Node randConstant() {
        int value = rand.nextInt(20) + 1;  // Random integer 1-20
        return new Node(new Const(value));
    }

    // Creates a random binary operator node with given left and right children
    private static Node randOperator(Node left, Node right) {
        int choice = rand.nextInt(4);
        Binop op;

        switch (choice) {
            case 0:
                op = new Plus();
                break;
            case 1:
                op = new Minus();
                break;
            case 2:
                op = new Mult();
                break;
            case 3:
                op = new Divide();
                break;
            default:
                op = new Plus();
        }

        return new Node(op, left, right);
    }

    public static void main(String[] args) {
        // Generate 5 random arithmetic problems
        for (int i = 0; i < 5; i++) {
            // Create 4 constant nodes with random values
            Node c1 = randConstant();
            Node c2 = randConstant();
            Node c3 = randConstant();
            Node c4 = randConstant();

            // Create the expression tree with 3 binary operators
            // Structure: ((c1 op c2) op (c3 op c4))
            Node b1 = randOperator(c1, c2);
            Node b2 = randOperator(c3, c4);
            Node root = randOperator(b1, b2);

            // Print the expression and its evaluation
            System.out.println(root.toString() + " = " + root.eval());
        }
    }
}