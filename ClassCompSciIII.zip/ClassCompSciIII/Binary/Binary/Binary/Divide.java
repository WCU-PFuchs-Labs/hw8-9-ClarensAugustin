package Binary;

public class Divide extends Binop {

    public double right;
    public double left;

    public double eval(double right, double left){
        this.right = right;
        this.left = left;

        return left / right;
    }

    public String toString(){
        // return "(" + left + "/" + right + ")";
        return " / ";
    }
}
