package Binary;

public abstract class Op {

    public abstract String toString();
}
