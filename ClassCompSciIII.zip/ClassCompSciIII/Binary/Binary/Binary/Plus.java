package Binary;

public class Plus extends Binop {

    public double right;
    public double left;

    public double eval(double left, double right){
        this.right = right;
        this.left = left;

        return left + right;
    }

    public String toString(){
        //return "(" + left + " + " + right + ")";
        return " + ";
    }
}
