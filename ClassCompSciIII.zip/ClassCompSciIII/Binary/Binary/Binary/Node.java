package Binary;

public class Node {
    private Node left;
    private Node right;
    private Op operation;

    public Node(Unop operation){

        this.operation = operation;
        this.left = null;
        this.right = null;
    }

    public Node(Binop operation, Node left, Node right){
        this.left = left;
        this.right = right;
        this.operation = operation;
    }

    public double eval() {
        if (operation instanceof Unop){
            return ((Unop)operation).eval();
        } else if (operation instanceof Binop) {
            //return ((Binop)operation).eval(left.eval(), right.eval());
            double leftVal = left.eval();
            double rightVal = right.eval();
            return ((Binop) operation).eval(leftVal, rightVal);
        } else { System.err.println("Error operation is not a Unop or a Binop!");
            return 0.0;
        }
    }

    public String toString(){
        if (operation instanceof Unop) {
            return operation.toString();
        } else {
            return "(" + left.toString() + operation.toString() + right.toString() + ")";
        }
    }
}
