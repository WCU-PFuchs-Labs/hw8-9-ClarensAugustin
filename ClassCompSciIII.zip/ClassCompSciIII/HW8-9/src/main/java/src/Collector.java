package src;

public interface Collector {
    void collect(Node node);
}
