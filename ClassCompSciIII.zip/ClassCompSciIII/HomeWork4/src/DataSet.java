import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class DataSet {

    private ArrayList<DataRow> data;
    private int numIndependantVariables;

    public DataSet(String fileName){
        data = new ArrayList<>();
        numIndependantVariables = 0;

        try {
            Scanner scanner = new Scanner(new File(fileName));

            // Skip the header line if exist
            if (scanner.hasNextLine()){
                scanner.nextLine();
            }

            // read each line of data
            while (scanner.hasNextLine()){
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) continue;

                // split by comma and remove whitespace
                String [] values = line.split(",");

                // First value is y (dependent variable)
                double y = Double.parseDouble(values[0].trim());

                // rest are x values independent variables)
                double [] x = new double[values.length - 1];
                for (int i = 1; i < values.length; i++){
                    x[i - 1] = Double.parseDouble(values[i].trim());
                }

                // Set number of independent variables from first row
                if (data.isEmpty()) {
                    numIndependantVariables = x.length;
                }

                data.add(new DataRow(y, x));
            }

            scanner.close();
        } catch (FileNotFoundException e){
            System.err.println("File not found: " + fileName);
        }
    }

    public ArrayList<DataRow> getRows(){
        return data;
    }

    public int getNumIndependantVariables() {
        return numIndependantVariables;
    }


}
