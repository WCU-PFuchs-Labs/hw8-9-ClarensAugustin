import java.util.ArrayList;

public class AlgebraicFraction {

    protected ArrayList<Object> numerator;
    protected ArrayList<Object> denominator;

    public AlgebraicFraction(Object[] num, Object[] denom) {
        // Initializing
        numerator = new ArrayList<Object>();
        denominator = new ArrayList<Object>();

        // adding all elements from num to numerator arrayList
        for (int i = 0; i < num.length; i++) {
            numerator.add(num[i]);
        }

        // adding all denom array elements to denoinator arrayList
        for (int i = 0; i < denom.length; i++) {
            denominator.add(denom[i]);
        }


    }

    private void reduce(){
        ArrayList<Object> numCopy = new ArrayList<>(numerator);

        for (Object n : numCopy){
            if (numerator.contains(n) && denominator.contains(n)) {
                numerator.remove(n);
                denominator.remove(n);
            }

        }
    }


    public AlgebraicFraction multiply(AlgebraicFraction otherFraction) {

        // combining numerator
        ArrayList<Object> combinedNumerator = new ArrayList<Object>();
        combinedNumerator.addAll(this.numerator);
        combinedNumerator.addAll(otherFraction.numerator);

        // combine denominator
        ArrayList<Object> combineDenominator = new ArrayList<Object>();
        combineDenominator.addAll(this.denominator);
        combineDenominator.addAll(otherFraction.denominator);

        Object[] numArray = combinedNumerator.toArray();
        Object[] denomArray = combineDenominator.toArray();

        // combining parts
        return new AlgebraicFraction(numArray, denomArray);
    }

    public String toString() {

        if(numerator.equals(denominator)){
            return "1";
        }

        if(denominator.isEmpty()){
            return "1";
        }

        if(denominator.isEmpty()){
            return "1";
        }
        StringBuilder result = new StringBuilder();

        if(numerator.size() == 1){
            result.append(numerator.get(0));
        } else {
            result.append("( ");
            for (int i = 0; i < numerator.size(); i++) {
                result.append(numerator.get(i));
                if (i < numerator.size() - 1) {
                    result.append(" ");
                }
            }
            result.append(" )");
        }

        result.append(" / ");

        if (denominator.isEmpty()){
            result.append("1");
        } else if (denominator.size() == 1) {
            result.append(denominator.get(0));
        } else {
            result.append("( ");
            for (int i = 0; i < denominator.size(); i++) {
                result.append(denominator.get(i));
                if (i < denominator.size() - 1) {
                    result.append(" ");
                }
            }
            result.append(" ) ");
        }

        /*if (numerator.size() == denominator.size()){
            boolean equal = true;
            for(int i = 0; i < numerator.size(); i++) {
                    if (!numerator.get(i).equals(denominator.get(i))){
                        equal = false;
                        break;
                    }
                }
            if (equal){
                System.out.print("1");
            }
        }  */

      /*  for (int i = 0; i < numerator.size(); i ++){
            for (int k = 0; k < denominator.size(); i++){
                if(numerator.get(i).equals(denominator.get(k))){
                    System.out.print("1");
                }
            }
        }

       */

        return result.toString();
    }

    public static void main(String[] args){
        String[] num1 = {"a"};
        String[] den1 = {"c"};
        AlgebraicFraction f1 = new AlgebraicFraction(num1, den1);
        String[] num2 = {"b","miles"};
        String[] den2 = {"hour"};
        AlgebraicFraction f2 = new AlgebraicFraction(num2, den2);
        String[] num3 = {"x","y","hour"};
        String[] den3 = {"b"};
        AlgebraicFraction f3 = new AlgebraicFraction(num3, den3);
        String[] num4 = {"x","y"};
        String[] den4 = {"x","y"};
        AlgebraicFraction f4 = new AlgebraicFraction(num4, den4);

      /* System.out.println("f1.numerator    = " + f1.numerator);
        System.out.println("f1.denominator  = " + f1.denominator);
        System.out.println("f2.numerator    = " + f2.numerator);
        System.out.println("f2.numerator    = " + f2.denominator);
        System.out.println("f3.numerator    = " + f3.numerator);
        System.out.println("f3.denominator  = " + f3.denominator);
        System.out.println("f4.numerator    = " + f4.numerator);
        System.out.println("f4.denonimator  = " + f4.denominator);
        */

        System.out.println("f1              = " + f1);
        System.out.println("f2              = " + f2);
        System.out.println("f3              = " + f3);
        System.out.println("f4              = " + f4);
        System.out.println("f1 * f2         = " + f1.multiply(f2));
        System.out.println("f3 * f2         = " + f3.multiply(f2));
        System.out.println("f1 * f4         = " + f1.multiply(f4));
    }
}
