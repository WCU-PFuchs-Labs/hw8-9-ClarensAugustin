import java.util.ArrayList;
import java.lang.StringBuilder;
import java.util.Random;

public class GPTree implements Collector {
    private Node root;
    private ArrayList<Node> crossNodes;


    public void collect(Node node) {
        // add node if not terminal leaf
        if (!node.isLeaf()) {
            crossNodes.add(node);
        }
    }

    public void traverse(){
        crossNodes = new ArrayList<Node>();
        root.traverse(this);
    }

    // return a string with all the binop strings

    public String getCrossNodes() {
        StringBuilder string = new StringBuilder();
        int lastIndex = crossNodes.size() -1;
        for (int i = 0; i < lastIndex; ++i){
            Node node = crossNodes.get(i);
            string.append(node.toString());
            string.append(";");
        }
        string.append(crossNodes.get(lastIndex));
        return string.toString();
    }

    // implements left child to left and right child to right
    public void crossover(GPTree tree, Random rand){
        // find the points for crossover
        this.traverse();
        tree.traverse();
        int thisPoint = rand.nextInt(this.crossNodes.size());
        int treePoint = rand.nextInt(this.crossNodes.size());
        boolean left = rand.nextBoolean();
        // get connection points
        Node thisTrunk = crossNodes.get(thisPoint);
        Node treeTrunk = tree.crossNodes.get(treePoint);

        if(left) {
            thisTrunk.swapLeft(treeTrunk);
        } else {
            thisTrunk.swapRight(treeTrunk);
        }
    }

    GPTree () {
        root = null;
    }

    public GPTree (NodeFactory n, int maxDepth, Random rand) {
        root = n.getOperator(rand);
        root.addRandomKids(n, maxDepth, rand);
    }

    public String toString() {
        return root.toString();
    }

    public double eval(double [] data) {
        return root.eval(data);
    }
}
