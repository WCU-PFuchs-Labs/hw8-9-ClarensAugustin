import java.util.ArrayList;

public class RectangleDemo {

    public static void main(String [] args) {
        Rectangle<Integer> rectangle = new Rectangle(5, 3);

        int l = rectangle.getLength();
        int w = rectangle.getWidth();
        double area = l * w;

        //System.out.println(l * w);
        System.out.println(rectangle.getLength() * rectangle.getWidth());
    }
}
