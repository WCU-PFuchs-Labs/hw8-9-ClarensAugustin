import java.util.*;
public class ClassPractice {

    public static void main(String[] args){

        Scanner b = new Scanner(System.in);
        System.out.println("Enter an integer number: ");
         int num = b.nextInt();
         System.out.println(num);

        System.out.println("Enter another integer number: ");
        int num2 = b.nextInt();
        System.out.println(num2);


        num = num2;
        System.out.println(num);

    }
}
