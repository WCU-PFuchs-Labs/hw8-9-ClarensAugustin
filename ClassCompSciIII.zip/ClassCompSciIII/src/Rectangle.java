public class Rectangle <T>{

    private T length, width;
    public Rectangle(T l, T w){
        length = l;
        width = w;
    }

    public T getLength(){ return length; }
    public T getWidth(){ return width; }

    public String toString(){
        return new String("The length is "+length+".\nThe width is "+width+".");
    }
}
