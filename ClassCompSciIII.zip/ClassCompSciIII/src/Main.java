public class Main {
    public static void main(String[] args) {

    }
    public void printSuffix(String a,int b) {

        int last3 = a.length() - b;

        String word = a.substring(last3);

        System.out.println("_" + word);
    }
}