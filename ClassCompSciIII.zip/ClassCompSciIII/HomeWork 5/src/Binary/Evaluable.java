package Binary;

public interface Evaluable {
    double eval(double[] values);
}
