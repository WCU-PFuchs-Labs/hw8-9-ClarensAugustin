package Binary;

public abstract class Binop extends Op{

    public abstract double eval(double left, double right);

    public abstract String toString();
}