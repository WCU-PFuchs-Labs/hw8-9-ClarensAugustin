package Binary;

public interface Stringable {
    String toString();
}
