package Binary;

public class Node implements Evaluable {

    private Node left;
    private Node right;
    private Unop unop;
    private Binop binop;

    public Node(Unop unop){

        this.unop = unop;
        this.left = null;
        this.right = null;
        this.binop = null;
    }

    public Node(Binop binop, Node left, Node right){
        this.left = left;
        this.right = right;
        this.binop = binop;
        this.unop = null;
    }

    public double eval(double[] values) {
        if (unop != null){
            return unop.eval(values);
        } else {
            //return binop
            double leftVal = left.eval(values);
            double rightVal = right.eval(values);
            return binop.eval(leftVal, rightVal);
        }
    }

    public String toString(){
        if (unop != null) {
            return unop.toString();
        } else {
            return "(" + left.toString() + binop.toString() + right.toString() + ")";
        }
    }
}

