
    public abstract class Unop  {

        public abstract double eval(double [] values);

        @Override
        public abstract String toString();
    }

