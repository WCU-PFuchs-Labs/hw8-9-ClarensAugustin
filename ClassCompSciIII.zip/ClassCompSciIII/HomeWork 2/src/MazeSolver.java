// Clarens Augustin
import java.util.ArrayList;

public class MazeSolver {

    // Constant variables, variables that belong to the class itself
    private static final char OPEN = '.';
    private static final char BLOCKED = '#';
    private static final char START = 'S';
    private static final char GOAL = 'G';
    private static final char MARKED = '-';
    private static final char UNMARKED = '+';

    // Instance variables, attributes of the class.
    private char[][] maze;
    private ArrayList<String> mazePath;
    private int numCellsVisited;
    private int mazesSolved;
    private int mazesTried;

    // directions constants
    private static final String NORTH = "North";
    private static final String SOUTH = "South";
    private static final String EAST = "East";
    private static final String WEST = "West";
    // constructor
    public MazeSolver() {
        this.mazePath = new ArrayList<>();
        this.numCellsVisited = 0;
        this.mazesSolved = 0;
        this.mazesTried = 0;
    }

    public boolean solveMaze(char[][] maze) {
        this.maze = maze;
        this.mazesTried++;
        this.numCellsVisited = 0;
        this.mazePath.clear();
        //return false;

        // start position
        int startRow = -1;
        int startCol = -1;
        for (int i = 0; i < maze.length; i++) {
            for (int k = 0; k < maze[i].length; k++) {
                if (maze[i][k] == START) {
                    startRow = i;
                    startCol = k;
                    break;
                }
            }
            if (startRow != -1) {
                break;
            }
        }

        if (startRow == -1 || startCol == -1) {
            System.out.println("Could not find START. Maze contents:");
            for (int i = 0; i < maze.length; i++) {
                for (int k = 0; k < maze[i].length; k++) {
                    System.out.println("[" + i + "][" + k + "] = '" + maze[i][k] + "' (ASCII " + (int)maze[i][k] + ")");
                }
            }
            return false;
        }


        boolean solved = findPath(startCol, startRow);
        if(solved)
        {
            this.mazesSolved++;
        }
        return solved;

    }
    private boolean findPath(int col, int row){
        //System.out.println("Start found at row=" + row + ", col=" + col);

        // base case for recursive.
        if (row < 0 || row >= maze.length || col < 0 || col >= maze[0].length  ){
            return false; // it will be out of bounds
        }

        char current = maze[row][col];

        // check if maze is blocked or visited
        if (current == BLOCKED || current == MARKED) {
            return false;
        }

        // check cell validity
        if (current != OPEN && current != START && current != UNMARKED && current != GOAL){
            return false;
        }

        // check if goal is found
        if (current == GOAL){
            numCellsVisited++;
            return true;
        }

        // marking visited blocks
        // char originalChar = maze[row][col];
        maze[row][col] = MARKED;
        numCellsVisited++;
        //mazePath.add("(" + col + "," + row + ")");


        // try all four directions
        if (findPath(col +1, row)){
            mazePath.add(0,EAST);
            return true;
        }

        if (findPath(col, row - 1)){
            mazePath.add(0, NORTH);
            return true;
        }

        if(findPath(col, row + 1)){
            mazePath.add(0,SOUTH);
            return true;
        }


        if(findPath(col - 1, row)){
            mazePath.add(0,WEST);
            return true;
        }

        // unmark the cell
        maze[row][col] = UNMARKED;
        //mazePath.remove(mazePath.size() - 1);
        return false;
    }



    public String [] getMoves(){

        if(mazePath.isEmpty()){
            return null;
        }
        return mazePath.toArray(new String[0]);
    }

    public int getNumCellsVisited(){
        return numCellsVisited;
    }

    public double getPerformance(){
        if (mazesTried == 0) {
            return 0.0;
        }
        return (double) mazesSolved / mazesTried;
    }

}